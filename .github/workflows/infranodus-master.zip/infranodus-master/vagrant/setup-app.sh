#!/usr/bin/env bash

# Install dependencies
cd /vagrant
npm install
