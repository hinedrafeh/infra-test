exports.render = function(req, res) {
    res.render('home', {
        title:
            'Text to Graph Network Visualization and Insight Analytics Tool - InfraNodus.Com',
    })
}
